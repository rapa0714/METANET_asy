//step1 : .html => load()
$(function(){
	$('#letter-a a').click(function(){
		$('#dictionary').hide().load('a.html', function(){
			$(this).fadeIn();
		});
		return false; //기본이벤트 취소
	});
});

//step2 : json => $.getJSON
//$(function(){
//	$('#letter-b a').click(function(){
//		$.getJSON('b.json',function(data){ //이 data가 배열
//			$('#dictionary').empty(); //dictionary안에 있는 내용물을 지워라.empty()
//			//결과값 : [{},{}] => HTML
//			$.each(data, function(index, item){
//				var html = ' <div class = "entry"> ';
//				html += ' <h3 class ="term"> '+ item.term + '</h3>';
//				html += ' <div class ="part"> '+ item.part + '</div>';
//				html += ' <div class ="definition"> '+ item.definition + '</div>';
//				html += ' </div>';
//				$('#dictionary').append(html);
//			});
//		});
//		return false; //기본이벤트 취소
//	});
//});

//step2-1 : ajax함수로 변환
$(function(){
	$('#letter-b a').click(function(){
		$.ajax({
			url: 'b.json',
			type: 'get',
			success: function(data){
				$.each(data, function(index, item){
					var html = ' <div class = "entry"> ';
					html += ' <h3 class ="term"> '+ item.term + '</h3>';
					html += ' <div class ="part"> '+ item.part + '</div>';
					html += ' <div class ="definition"> '+ item.definition + '</div>';
					html += ' </div>';
					$('#dictionary').append(html);
					
				});
				
			}
		});
		return false; //기본이벤트 취소
	});
});

//step3 : JavaScript => $.getScript()
$(function(){
	$('#letter-c a').click(function(){
		$.getScript('c.js');
		return false; //기본이벤트 취소
	});
});

//step4 : xml => $.get
$(function(){
	$('#letter-d a').click(function(){
		//xml => html => 화면출력
		$.get('d.xml',function(data){ //data변수안에는 <entries>
			$(data).find('entry').each(function(index){//자식 요소 찾기.=>find()
				$entry =$(this);
				var html = ' <div class = "entry"> ';
				html += ' <h3 class ="term"> '+ $entry.attr('term') + '</h3>';
				html += ' <div class ="part"> '+ $entry.attr('part') + '</div>';
				html += ' <div class ="definition"> '+ $entry.find('definition').text() + '</div>';
				html += ' </div>';
				$('#dictionary').append(html);
			});			
		});		
		return false; //기본이벤트 취소
	});
});

//step5 
$(function(){
	$('#letter-e a').click(function(){
		$.get('server3.jsp',{'term':$(this).text()}, function(data){
			$('#dictionary').text(data);
		});
		
		return false; //기본이벤트 취소
	});
});

//step6 : $.ajax , serialize()
$(function(){
	$('#letter-f form').submit(function(){
		$.ajax({
			url: 'server3.jsp',
			type: 'post',
			data: $(this).serialize(),
			dataType: 'text',
			success: function(data){
				$('#dictionary').text(data);
			}
		});
		return false; //기본이벤트 <a,form> 취소
	});
});





