$(function(){
	$('.quantity input').change(function(){
		var totalCost = 0;
		var totalQuantity =0;
		var taxCost = 0;
		var shippingCost=0;
		$('table tbody tr').each(function(index){
			var price = parseFloat($(this).find('.price').text().replace(/^[^\d.]/,'')); //find():자식찾는함수
			price = isNaN(price) ? 0 : price;
			
			var quantity = parseInt($(this).find('.quantity input').val());
			quantity = isNaN(quantity) ? 0 : quantity;
			
			var cost = price * quantity;
			$(this).find('.cost').text('$'+cost.toFixed(2)); //text를 넣을때도 text함수 사용
			
			totalCost +=cost;
			totalQuantity +=quantity;
			taxCost = totalCost * 0.06;
			shippingCost=totalQuantity*2;
		});
		
		$('.subtotal .cost').text('$'+totalCost.toFixed(2));
		$('.shipping .quantity').text(totalQuantity);
		$('table tfoot tr:eq(1) .cost').text('$'+taxCost.toFixed(2));
		$('table tfoot tr:eq(2) .cost').text('$'+shippingCost.toFixed(2));
		$('table tfoot tr:eq(3) .cost').text('$'+(totalCost+taxCost+shippingCost).toFixed(2));
	});
});

