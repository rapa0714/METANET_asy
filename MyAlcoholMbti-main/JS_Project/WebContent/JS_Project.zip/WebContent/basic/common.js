function kosa3(){
	alert('kosa3');
}